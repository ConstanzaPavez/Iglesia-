import React from 'react';
import CertificateList from '../components/CertificateList';

const CertificatesPage = () => {
  return (
    <div>
      <CertificateList />
    </div>
  );
};

export default CertificatesPage;
